package com.santosenoque.cabdriver

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
